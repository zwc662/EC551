/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_2045190055_init();
    xilinxcorelib_ver_m_00000000001358910285_3837824132_init();
    xilinxcorelib_ver_m_00000000001687936702_0827547914_init();
    xilinxcorelib_ver_m_00000000000277421008_1816587433_init();
    xilinxcorelib_ver_m_00000000001485706734_1431566541_init();
    work_m_00000000000621624591_1999356529_init();
    work_m_00000000000664375980_1321836778_init();
    work_m_00000000003190674542_3402371208_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000003190674542_3402371208");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
