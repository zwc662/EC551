/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//ad/eng/users/z/w/zwc662/EC551/BVB_Simple/BVB_Simple.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};
static int ng4[] = {4, 0};



static void Cont_46_0(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char t19[8];
    char t22[8];
    char t36[8];
    char t46[8];
    char t47[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 4448U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1368U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 0);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 0);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t20 = (t0 + 1688U);
    t21 = *((char **)t20);
    t20 = (t0 + 1648U);
    t23 = (t20 + 72U);
    t24 = *((char **)t23);
    t25 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t22, 10, t21, t24, 2, t25, 32, 1);
    memset(t19, 0, 8);
    t26 = (t19 + 4);
    t27 = (t22 + 4);
    t28 = *((unsigned int *)t22);
    t29 = (~(t28));
    *((unsigned int *)t19) = t29;
    *((unsigned int *)t26) = 0;
    if (*((unsigned int *)t27) != 0)
        goto LAB5;

LAB4:    t34 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t34 & 1023U);
    t35 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t35 & 1023U);
    t37 = (t0 + 1848U);
    t38 = *((char **)t37);
    memset(t36, 0, 8);
    t37 = (t36 + 4);
    t39 = (t38 + 4);
    t40 = *((unsigned int *)t38);
    t41 = (t40 >> 0);
    *((unsigned int *)t36) = t41;
    t42 = *((unsigned int *)t39);
    t43 = (t42 >> 0);
    *((unsigned int *)t37) = t43;
    t44 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t44 & 1023U);
    t45 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t45 & 1023U);
    memset(t46, 0, 8);
    xsi_vlog_unsigned_multiply(t46, 10, t19, 10, t36, 10);
    memset(t47, 0, 8);
    xsi_vlog_unsigned_add(t47, 10, t18, 10, t46, 10);
    t48 = (t0 + 7224);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memset(t52, 0, 8);
    t53 = 1023U;
    t54 = t53;
    t55 = (t47 + 4);
    t56 = *((unsigned int *)t47);
    t53 = (t53 & t56);
    t57 = *((unsigned int *)t55);
    t54 = (t54 & t57);
    t58 = (t52 + 4);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t59 | t53);
    t60 = *((unsigned int *)t58);
    *((unsigned int *)t58) = (t60 | t54);
    xsi_driver_vfirst_trans(t48, 0, 9);
    t61 = (t0 + 7000);
    *((int *)t61) = 1;

LAB1:    return;
LAB5:    t30 = *((unsigned int *)t19);
    t31 = *((unsigned int *)t27);
    *((unsigned int *)t19) = (t30 | t31);
    t32 = *((unsigned int *)t26);
    t33 = *((unsigned int *)t27);
    *((unsigned int *)t26) = (t32 | t33);
    goto LAB4;

}

static void Cont_47_1(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;

LAB0:    t1 = (t0 + 4696U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1528U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 0);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 0);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t19 = (t0 + 7288);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memset(t23, 0, 8);
    t24 = 255U;
    t25 = t24;
    t26 = (t18 + 4);
    t27 = *((unsigned int *)t18);
    t24 = (t24 & t27);
    t28 = *((unsigned int *)t26);
    t25 = (t25 & t28);
    t29 = (t23 + 4);
    t30 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t30 | t24);
    t31 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t31 | t25);
    xsi_driver_vfirst_trans(t19, 0, 7);
    t32 = (t0 + 7016);
    *((int *)t32) = 1;

LAB1:    return;
}

static void Cont_48_2(char *t0)
{
    char t3[8];
    char t5[8];
    char t19[8];
    char t29[8];
    char *t1;
    char *t2;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;

LAB0:    t1 = (t0 + 4944U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1688U);
    t4 = *((char **)t2);
    t2 = (t0 + 1648U);
    t6 = (t2 + 72U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t5, 8, t4, t7, 2, t8, 32, 1);
    memset(t3, 0, 8);
    t9 = (t3 + 4);
    t10 = (t5 + 4);
    t11 = *((unsigned int *)t5);
    t12 = (~(t11));
    *((unsigned int *)t3) = t12;
    *((unsigned int *)t9) = 0;
    if (*((unsigned int *)t10) != 0)
        goto LAB5;

LAB4:    t17 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t17 & 255U);
    t18 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t18 & 255U);
    t20 = (t0 + 2168U);
    t21 = *((char **)t20);
    memset(t19, 0, 8);
    t20 = (t19 + 4);
    t22 = (t21 + 4);
    t23 = *((unsigned int *)t21);
    t24 = (t23 >> 0);
    *((unsigned int *)t19) = t24;
    t25 = *((unsigned int *)t22);
    t26 = (t25 >> 0);
    *((unsigned int *)t20) = t26;
    t27 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t27 & 255U);
    t28 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t28 & 255U);
    memset(t29, 0, 8);
    xsi_vlog_unsigned_multiply(t29, 8, t3, 8, t19, 8);
    t30 = (t0 + 7352);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memset(t34, 0, 8);
    t35 = 255U;
    t36 = t35;
    t37 = (t29 + 4);
    t38 = *((unsigned int *)t29);
    t35 = (t35 & t38);
    t39 = *((unsigned int *)t37);
    t36 = (t36 & t39);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t41 | t35);
    t42 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t42 | t36);
    xsi_driver_vfirst_trans(t30, 0, 7);
    t43 = (t0 + 7032);
    *((int *)t43) = 1;

LAB1:    return;
LAB5:    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t10);
    *((unsigned int *)t3) = (t13 | t14);
    t15 = *((unsigned int *)t9);
    t16 = *((unsigned int *)t10);
    *((unsigned int *)t9) = (t15 | t16);
    goto LAB4;

}

static void Cont_46_3(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char t19[8];
    char t22[8];
    char t36[8];
    char t46[8];
    char t47[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 5192U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1368U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 10);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 10);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t20 = (t0 + 1688U);
    t21 = *((char **)t20);
    t20 = (t0 + 1648U);
    t23 = (t20 + 72U);
    t24 = *((char **)t23);
    t25 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t22, 10, t21, t24, 2, t25, 32, 1);
    memset(t19, 0, 8);
    t26 = (t19 + 4);
    t27 = (t22 + 4);
    t28 = *((unsigned int *)t22);
    t29 = (~(t28));
    *((unsigned int *)t19) = t29;
    *((unsigned int *)t26) = 0;
    if (*((unsigned int *)t27) != 0)
        goto LAB5;

LAB4:    t34 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t34 & 1023U);
    t35 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t35 & 1023U);
    t37 = (t0 + 1848U);
    t38 = *((char **)t37);
    memset(t36, 0, 8);
    t37 = (t36 + 4);
    t39 = (t38 + 4);
    t40 = *((unsigned int *)t38);
    t41 = (t40 >> 10);
    *((unsigned int *)t36) = t41;
    t42 = *((unsigned int *)t39);
    t43 = (t42 >> 10);
    *((unsigned int *)t37) = t43;
    t44 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t44 & 1023U);
    t45 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t45 & 1023U);
    memset(t46, 0, 8);
    xsi_vlog_unsigned_multiply(t46, 10, t19, 10, t36, 10);
    memset(t47, 0, 8);
    xsi_vlog_unsigned_add(t47, 10, t18, 10, t46, 10);
    t48 = (t0 + 7416);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memset(t52, 0, 8);
    t53 = 1023U;
    t54 = t53;
    t55 = (t47 + 4);
    t56 = *((unsigned int *)t47);
    t53 = (t53 & t56);
    t57 = *((unsigned int *)t55);
    t54 = (t54 & t57);
    t58 = (t52 + 4);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t59 | t53);
    t60 = *((unsigned int *)t58);
    *((unsigned int *)t58) = (t60 | t54);
    xsi_driver_vfirst_trans(t48, 10, 19);
    t61 = (t0 + 7048);
    *((int *)t61) = 1;

LAB1:    return;
LAB5:    t30 = *((unsigned int *)t19);
    t31 = *((unsigned int *)t27);
    *((unsigned int *)t19) = (t30 | t31);
    t32 = *((unsigned int *)t26);
    t33 = *((unsigned int *)t27);
    *((unsigned int *)t26) = (t32 | t33);
    goto LAB4;

}

static void Cont_47_4(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;

LAB0:    t1 = (t0 + 5440U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1528U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 10);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 10);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t19 = (t0 + 7480);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memset(t23, 0, 8);
    t24 = 255U;
    t25 = t24;
    t26 = (t18 + 4);
    t27 = *((unsigned int *)t18);
    t24 = (t24 & t27);
    t28 = *((unsigned int *)t26);
    t25 = (t25 & t28);
    t29 = (t23 + 4);
    t30 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t30 | t24);
    t31 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t31 | t25);
    xsi_driver_vfirst_trans(t19, 8, 15);
    t32 = (t0 + 7064);
    *((int *)t32) = 1;

LAB1:    return;
}

static void Cont_48_5(char *t0)
{
    char t3[8];
    char t5[8];
    char t19[8];
    char t29[8];
    char *t1;
    char *t2;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;

LAB0:    t1 = (t0 + 5688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1688U);
    t4 = *((char **)t2);
    t2 = (t0 + 1648U);
    t6 = (t2 + 72U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t5, 8, t4, t7, 2, t8, 32, 1);
    memset(t3, 0, 8);
    t9 = (t3 + 4);
    t10 = (t5 + 4);
    t11 = *((unsigned int *)t5);
    t12 = (~(t11));
    *((unsigned int *)t3) = t12;
    *((unsigned int *)t9) = 0;
    if (*((unsigned int *)t10) != 0)
        goto LAB5;

LAB4:    t17 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t17 & 255U);
    t18 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t18 & 255U);
    t20 = (t0 + 2168U);
    t21 = *((char **)t20);
    memset(t19, 0, 8);
    t20 = (t19 + 4);
    t22 = (t21 + 4);
    t23 = *((unsigned int *)t21);
    t24 = (t23 >> 8);
    *((unsigned int *)t19) = t24;
    t25 = *((unsigned int *)t22);
    t26 = (t25 >> 8);
    *((unsigned int *)t20) = t26;
    t27 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t27 & 255U);
    t28 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t28 & 255U);
    memset(t29, 0, 8);
    xsi_vlog_unsigned_multiply(t29, 8, t3, 8, t19, 8);
    t30 = (t0 + 7544);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memset(t34, 0, 8);
    t35 = 255U;
    t36 = t35;
    t37 = (t29 + 4);
    t38 = *((unsigned int *)t29);
    t35 = (t35 & t38);
    t39 = *((unsigned int *)t37);
    t36 = (t36 & t39);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t41 | t35);
    t42 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t42 | t36);
    xsi_driver_vfirst_trans(t30, 8, 15);
    t43 = (t0 + 7080);
    *((int *)t43) = 1;

LAB1:    return;
LAB5:    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t10);
    *((unsigned int *)t3) = (t13 | t14);
    t15 = *((unsigned int *)t9);
    t16 = *((unsigned int *)t10);
    *((unsigned int *)t9) = (t15 | t16);
    goto LAB4;

}

static void Cont_46_6(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char t19[8];
    char t22[8];
    char t36[8];
    char t46[8];
    char t47[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;

LAB0:    t1 = (t0 + 5936U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng3)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1368U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 20);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 20);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t20 = (t0 + 1688U);
    t21 = *((char **)t20);
    t20 = (t0 + 1648U);
    t23 = (t20 + 72U);
    t24 = *((char **)t23);
    t25 = ((char*)((ng3)));
    xsi_vlog_generic_get_index_select_value(t22, 10, t21, t24, 2, t25, 32, 1);
    memset(t19, 0, 8);
    t26 = (t19 + 4);
    t27 = (t22 + 4);
    t28 = *((unsigned int *)t22);
    t29 = (~(t28));
    *((unsigned int *)t19) = t29;
    *((unsigned int *)t26) = 0;
    if (*((unsigned int *)t27) != 0)
        goto LAB5;

LAB4:    t34 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t34 & 1023U);
    t35 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t35 & 1023U);
    t37 = (t0 + 1848U);
    t38 = *((char **)t37);
    memset(t36, 0, 8);
    t37 = (t36 + 4);
    t39 = (t38 + 4);
    t40 = *((unsigned int *)t38);
    t41 = (t40 >> 20);
    *((unsigned int *)t36) = t41;
    t42 = *((unsigned int *)t39);
    t43 = (t42 >> 20);
    *((unsigned int *)t37) = t43;
    t44 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t44 & 1023U);
    t45 = *((unsigned int *)t37);
    *((unsigned int *)t37) = (t45 & 1023U);
    memset(t46, 0, 8);
    xsi_vlog_unsigned_multiply(t46, 10, t19, 10, t36, 10);
    memset(t47, 0, 8);
    xsi_vlog_unsigned_add(t47, 10, t18, 10, t46, 10);
    t48 = (t0 + 7608);
    t49 = (t48 + 56U);
    t50 = *((char **)t49);
    t51 = (t50 + 56U);
    t52 = *((char **)t51);
    memset(t52, 0, 8);
    t53 = 1023U;
    t54 = t53;
    t55 = (t47 + 4);
    t56 = *((unsigned int *)t47);
    t53 = (t53 & t56);
    t57 = *((unsigned int *)t55);
    t54 = (t54 & t57);
    t58 = (t52 + 4);
    t59 = *((unsigned int *)t52);
    *((unsigned int *)t52) = (t59 | t53);
    t60 = *((unsigned int *)t58);
    *((unsigned int *)t58) = (t60 | t54);
    xsi_driver_vfirst_trans(t48, 20, 29);
    t61 = (t0 + 7096);
    *((int *)t61) = 1;

LAB1:    return;
LAB5:    t30 = *((unsigned int *)t19);
    t31 = *((unsigned int *)t27);
    *((unsigned int *)t19) = (t30 | t31);
    t32 = *((unsigned int *)t26);
    t33 = *((unsigned int *)t27);
    *((unsigned int *)t26) = (t32 | t33);
    goto LAB4;

}

static void Cont_47_7(char *t0)
{
    char t4[8];
    char t8[8];
    char t18[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;

LAB0:    t1 = (t0 + 6184U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 1648U);
    t5 = (t2 + 72U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng3)));
    xsi_vlog_generic_get_index_select_value(t4, 10, t3, t6, 2, t7, 32, 1);
    t9 = (t0 + 1528U);
    t10 = *((char **)t9);
    memset(t8, 0, 8);
    t9 = (t8 + 4);
    t11 = (t10 + 4);
    t12 = *((unsigned int *)t10);
    t13 = (t12 >> 20);
    *((unsigned int *)t8) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 >> 20);
    *((unsigned int *)t9) = t15;
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 1023U);
    t17 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t17 & 1023U);
    memset(t18, 0, 8);
    xsi_vlog_unsigned_multiply(t18, 10, t4, 10, t8, 10);
    t19 = (t0 + 7672);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memset(t23, 0, 8);
    t24 = 255U;
    t25 = t24;
    t26 = (t18 + 4);
    t27 = *((unsigned int *)t18);
    t24 = (t24 & t27);
    t28 = *((unsigned int *)t26);
    t25 = (t25 & t28);
    t29 = (t23 + 4);
    t30 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t30 | t24);
    t31 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t31 | t25);
    xsi_driver_vfirst_trans(t19, 16, 23);
    t32 = (t0 + 7112);
    *((int *)t32) = 1;

LAB1:    return;
}

static void Cont_48_8(char *t0)
{
    char t3[8];
    char t5[8];
    char t19[8];
    char t29[8];
    char *t1;
    char *t2;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;

LAB0:    t1 = (t0 + 6432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 1688U);
    t4 = *((char **)t2);
    t2 = (t0 + 1648U);
    t6 = (t2 + 72U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng3)));
    xsi_vlog_generic_get_index_select_value(t5, 8, t4, t7, 2, t8, 32, 1);
    memset(t3, 0, 8);
    t9 = (t3 + 4);
    t10 = (t5 + 4);
    t11 = *((unsigned int *)t5);
    t12 = (~(t11));
    *((unsigned int *)t3) = t12;
    *((unsigned int *)t9) = 0;
    if (*((unsigned int *)t10) != 0)
        goto LAB5;

LAB4:    t17 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t17 & 255U);
    t18 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t18 & 255U);
    t20 = (t0 + 2168U);
    t21 = *((char **)t20);
    memset(t19, 0, 8);
    t20 = (t19 + 4);
    t22 = (t21 + 4);
    t23 = *((unsigned int *)t21);
    t24 = (t23 >> 16);
    *((unsigned int *)t19) = t24;
    t25 = *((unsigned int *)t22);
    t26 = (t25 >> 16);
    *((unsigned int *)t20) = t26;
    t27 = *((unsigned int *)t19);
    *((unsigned int *)t19) = (t27 & 255U);
    t28 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t28 & 255U);
    memset(t29, 0, 8);
    xsi_vlog_unsigned_multiply(t29, 8, t3, 8, t19, 8);
    t30 = (t0 + 7736);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    memset(t34, 0, 8);
    t35 = 255U;
    t36 = t35;
    t37 = (t29 + 4);
    t38 = *((unsigned int *)t29);
    t35 = (t35 & t38);
    t39 = *((unsigned int *)t37);
    t36 = (t36 & t39);
    t40 = (t34 + 4);
    t41 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t41 | t35);
    t42 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t42 | t36);
    xsi_driver_vfirst_trans(t30, 16, 23);
    t43 = (t0 + 7128);
    *((int *)t43) = 1;

LAB1:    return;
LAB5:    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t10);
    *((unsigned int *)t3) = (t13 | t14);
    t15 = *((unsigned int *)t9);
    t16 = *((unsigned int *)t10);
    *((unsigned int *)t9) = (t15 | t16);
    goto LAB4;

}

static void Always_63_9(char *t0)
{
    char t13[8];
    char t14[8];
    char t15[8];
    char t18[8];
    char t41[8];
    char t53[8];
    char t56[8];
    char t79[8];
    char t87[8];
    char t119[8];
    char t133[8];
    char t149[8];
    char t157[8];
    char t197[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    char *t54;
    char *t55;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t68;
    char *t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    char *t86;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    char *t92;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    char *t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    int t111;
    int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    char *t126;
    char *t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    char *t131;
    char *t132;
    char *t134;
    char *t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    char *t148;
    char *t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    char *t156;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t161;
    char *t162;
    char *t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    char *t171;
    char *t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    int t181;
    int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    char *t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    char *t195;
    char *t196;
    char *t198;
    char *t199;
    char *t200;
    char *t201;
    char *t202;
    char *t203;
    char *t204;
    unsigned int t205;
    int t206;

LAB0:    t1 = (t0 + 6680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 7144);
    *((int *)t2) = 1;
    t3 = (t0 + 6712);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(63, ng0);

LAB5:    xsi_set_current_line(64, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(67, ng0);

LAB10:    xsi_set_current_line(68, ng0);
    xsi_set_current_line(68, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3528);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB11:    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    t11 = ((char*)((ng2)));
    memset(t13, 0, 8);
    xsi_vlog_signed_minus(t13, 32, t5, 32, t11, 32);
    memset(t14, 0, 8);
    xsi_vlog_signed_less(t14, 32, t4, 32, t13, 32);
    t12 = (t14 + 4);
    t6 = *((unsigned int *)t12);
    t7 = (~(t6));
    t8 = *((unsigned int *)t14);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB12;

LAB13:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(64, ng0);

LAB9:    xsi_set_current_line(65, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    goto LAB8;

LAB12:    xsi_set_current_line(68, ng0);

LAB14:    xsi_set_current_line(69, ng0);
    t16 = (t0 + 2008U);
    t17 = *((char **)t16);
    t16 = (t0 + 1968U);
    t19 = (t16 + 72U);
    t20 = *((char **)t19);
    t21 = (t0 + 3528);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    xsi_vlog_generic_get_index_select_value(t18, 1, t17, t20, 2, t23, 32, 1);
    memset(t15, 0, 8);
    t24 = (t18 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t18);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB18;

LAB16:    if (*((unsigned int *)t24) == 0)
        goto LAB15;

LAB17:    t30 = (t15 + 4);
    *((unsigned int *)t15) = 1;
    *((unsigned int *)t30) = 1;

LAB18:    t31 = (t15 + 4);
    t32 = (t18 + 4);
    t33 = *((unsigned int *)t18);
    t34 = (~(t33));
    *((unsigned int *)t15) = t34;
    *((unsigned int *)t31) = 0;
    if (*((unsigned int *)t32) != 0)
        goto LAB20;

LAB19:    t39 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t39 & 1U);
    t40 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t40 & 1U);
    memset(t41, 0, 8);
    t42 = (t15 + 4);
    t43 = *((unsigned int *)t42);
    t44 = (~(t43));
    t45 = *((unsigned int *)t15);
    t46 = (t45 & t44);
    t47 = (t46 & 1U);
    if (t47 != 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t42) != 0)
        goto LAB23;

LAB24:    t49 = (t41 + 4);
    t50 = *((unsigned int *)t41);
    t51 = *((unsigned int *)t49);
    t52 = (t50 || t51);
    if (t52 > 0)
        goto LAB25;

LAB26:    memcpy(t87, t41, 8);

LAB27:    memset(t119, 0, 8);
    t120 = (t87 + 4);
    t121 = *((unsigned int *)t120);
    t122 = (~(t121));
    t123 = *((unsigned int *)t87);
    t124 = (t123 & t122);
    t125 = (t124 & 1U);
    if (t125 != 0)
        goto LAB41;

LAB42:    if (*((unsigned int *)t120) != 0)
        goto LAB43;

LAB44:    t127 = (t119 + 4);
    t128 = *((unsigned int *)t119);
    t129 = *((unsigned int *)t127);
    t130 = (t128 || t129);
    if (t130 > 0)
        goto LAB45;

LAB46:    memcpy(t157, t119, 8);

LAB47:    t189 = (t157 + 4);
    t190 = *((unsigned int *)t189);
    t191 = (~(t190));
    t192 = *((unsigned int *)t157);
    t193 = (t192 & t191);
    t194 = (t193 != 0);
    if (t194 > 0)
        goto LAB59;

LAB60:
LAB61:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t13, 0, 8);
    xsi_vlog_signed_add(t13, 32, t4, 32, t5, 32);
    t11 = (t0 + 3528);
    xsi_vlogvar_assign_value(t11, t13, 0, 0, 32);
    goto LAB11;

LAB15:    *((unsigned int *)t15) = 1;
    goto LAB18;

LAB20:    t35 = *((unsigned int *)t15);
    t36 = *((unsigned int *)t32);
    *((unsigned int *)t15) = (t35 | t36);
    t37 = *((unsigned int *)t31);
    t38 = *((unsigned int *)t32);
    *((unsigned int *)t31) = (t37 | t38);
    goto LAB19;

LAB21:    *((unsigned int *)t41) = 1;
    goto LAB24;

LAB23:    t48 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t48) = 1;
    goto LAB24;

LAB25:    t54 = (t0 + 2328U);
    t55 = *((char **)t54);
    t54 = (t0 + 2288U);
    t57 = (t54 + 72U);
    t58 = *((char **)t57);
    t59 = (t0 + 3528);
    t60 = (t59 + 56U);
    t61 = *((char **)t60);
    xsi_vlog_generic_get_index_select_value(t56, 1, t55, t58, 2, t61, 32, 1);
    memset(t53, 0, 8);
    t62 = (t56 + 4);
    t63 = *((unsigned int *)t62);
    t64 = (~(t63));
    t65 = *((unsigned int *)t56);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB31;

LAB29:    if (*((unsigned int *)t62) == 0)
        goto LAB28;

LAB30:    t68 = (t53 + 4);
    *((unsigned int *)t53) = 1;
    *((unsigned int *)t68) = 1;

LAB31:    t69 = (t53 + 4);
    t70 = (t56 + 4);
    t71 = *((unsigned int *)t56);
    t72 = (~(t71));
    *((unsigned int *)t53) = t72;
    *((unsigned int *)t69) = 0;
    if (*((unsigned int *)t70) != 0)
        goto LAB33;

LAB32:    t77 = *((unsigned int *)t53);
    *((unsigned int *)t53) = (t77 & 1U);
    t78 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t78 & 1U);
    memset(t79, 0, 8);
    t80 = (t53 + 4);
    t81 = *((unsigned int *)t80);
    t82 = (~(t81));
    t83 = *((unsigned int *)t53);
    t84 = (t83 & t82);
    t85 = (t84 & 1U);
    if (t85 != 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t80) != 0)
        goto LAB36;

LAB37:    t88 = *((unsigned int *)t41);
    t89 = *((unsigned int *)t79);
    t90 = (t88 & t89);
    *((unsigned int *)t87) = t90;
    t91 = (t41 + 4);
    t92 = (t79 + 4);
    t93 = (t87 + 4);
    t94 = *((unsigned int *)t91);
    t95 = *((unsigned int *)t92);
    t96 = (t94 | t95);
    *((unsigned int *)t93) = t96;
    t97 = *((unsigned int *)t93);
    t98 = (t97 != 0);
    if (t98 == 1)
        goto LAB38;

LAB39:
LAB40:    goto LAB27;

LAB28:    *((unsigned int *)t53) = 1;
    goto LAB31;

LAB33:    t73 = *((unsigned int *)t53);
    t74 = *((unsigned int *)t70);
    *((unsigned int *)t53) = (t73 | t74);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t70);
    *((unsigned int *)t69) = (t75 | t76);
    goto LAB32;

LAB34:    *((unsigned int *)t79) = 1;
    goto LAB37;

LAB36:    t86 = (t79 + 4);
    *((unsigned int *)t79) = 1;
    *((unsigned int *)t86) = 1;
    goto LAB37;

LAB38:    t99 = *((unsigned int *)t87);
    t100 = *((unsigned int *)t93);
    *((unsigned int *)t87) = (t99 | t100);
    t101 = (t41 + 4);
    t102 = (t79 + 4);
    t103 = *((unsigned int *)t41);
    t104 = (~(t103));
    t105 = *((unsigned int *)t101);
    t106 = (~(t105));
    t107 = *((unsigned int *)t79);
    t108 = (~(t107));
    t109 = *((unsigned int *)t102);
    t110 = (~(t109));
    t111 = (t104 & t106);
    t112 = (t108 & t110);
    t113 = (~(t111));
    t114 = (~(t112));
    t115 = *((unsigned int *)t93);
    *((unsigned int *)t93) = (t115 & t113);
    t116 = *((unsigned int *)t93);
    *((unsigned int *)t93) = (t116 & t114);
    t117 = *((unsigned int *)t87);
    *((unsigned int *)t87) = (t117 & t113);
    t118 = *((unsigned int *)t87);
    *((unsigned int *)t87) = (t118 & t114);
    goto LAB40;

LAB41:    *((unsigned int *)t119) = 1;
    goto LAB44;

LAB43:    t126 = (t119 + 4);
    *((unsigned int *)t119) = 1;
    *((unsigned int *)t126) = 1;
    goto LAB44;

LAB45:    t131 = (t0 + 1688U);
    t132 = *((char **)t131);
    t131 = ((char*)((ng1)));
    memset(t133, 0, 8);
    t134 = (t132 + 4);
    t135 = (t131 + 4);
    t136 = *((unsigned int *)t132);
    t137 = *((unsigned int *)t131);
    t138 = (t136 ^ t137);
    t139 = *((unsigned int *)t134);
    t140 = *((unsigned int *)t135);
    t141 = (t139 ^ t140);
    t142 = (t138 | t141);
    t143 = *((unsigned int *)t134);
    t144 = *((unsigned int *)t135);
    t145 = (t143 | t144);
    t146 = (~(t145));
    t147 = (t142 & t146);
    if (t147 != 0)
        goto LAB49;

LAB48:    if (t145 != 0)
        goto LAB50;

LAB51:    memset(t149, 0, 8);
    t150 = (t133 + 4);
    t151 = *((unsigned int *)t150);
    t152 = (~(t151));
    t153 = *((unsigned int *)t133);
    t154 = (t153 & t152);
    t155 = (t154 & 1U);
    if (t155 != 0)
        goto LAB52;

LAB53:    if (*((unsigned int *)t150) != 0)
        goto LAB54;

LAB55:    t158 = *((unsigned int *)t119);
    t159 = *((unsigned int *)t149);
    t160 = (t158 & t159);
    *((unsigned int *)t157) = t160;
    t161 = (t119 + 4);
    t162 = (t149 + 4);
    t163 = (t157 + 4);
    t164 = *((unsigned int *)t161);
    t165 = *((unsigned int *)t162);
    t166 = (t164 | t165);
    *((unsigned int *)t163) = t166;
    t167 = *((unsigned int *)t163);
    t168 = (t167 != 0);
    if (t168 == 1)
        goto LAB56;

LAB57:
LAB58:    goto LAB47;

LAB49:    *((unsigned int *)t133) = 1;
    goto LAB51;

LAB50:    t148 = (t133 + 4);
    *((unsigned int *)t133) = 1;
    *((unsigned int *)t148) = 1;
    goto LAB51;

LAB52:    *((unsigned int *)t149) = 1;
    goto LAB55;

LAB54:    t156 = (t149 + 4);
    *((unsigned int *)t149) = 1;
    *((unsigned int *)t156) = 1;
    goto LAB55;

LAB56:    t169 = *((unsigned int *)t157);
    t170 = *((unsigned int *)t163);
    *((unsigned int *)t157) = (t169 | t170);
    t171 = (t119 + 4);
    t172 = (t149 + 4);
    t173 = *((unsigned int *)t119);
    t174 = (~(t173));
    t175 = *((unsigned int *)t171);
    t176 = (~(t175));
    t177 = *((unsigned int *)t149);
    t178 = (~(t177));
    t179 = *((unsigned int *)t172);
    t180 = (~(t179));
    t181 = (t174 & t176);
    t182 = (t178 & t180);
    t183 = (~(t181));
    t184 = (~(t182));
    t185 = *((unsigned int *)t163);
    *((unsigned int *)t163) = (t185 & t183);
    t186 = *((unsigned int *)t163);
    *((unsigned int *)t163) = (t186 & t184);
    t187 = *((unsigned int *)t157);
    *((unsigned int *)t157) = (t187 & t183);
    t188 = *((unsigned int *)t157);
    *((unsigned int *)t157) = (t188 & t184);
    goto LAB58;

LAB59:    xsi_set_current_line(69, ng0);

LAB62:    xsi_set_current_line(70, ng0);
    t195 = ((char*)((ng2)));
    t196 = (t0 + 3208);
    t198 = (t0 + 3208);
    t199 = (t198 + 72U);
    t200 = *((char **)t199);
    t201 = (t0 + 3528);
    t202 = (t201 + 56U);
    t203 = *((char **)t202);
    xsi_vlog_generic_convert_bit_index(t197, t200, 2, t203, 32, 1);
    t204 = (t197 + 4);
    t205 = *((unsigned int *)t204);
    t206 = (!(t205));
    if (t206 == 1)
        goto LAB63;

LAB64:    xsi_set_current_line(71, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 3368);
    t4 = (t0 + 3368);
    t5 = (t4 + 72U);
    t11 = *((char **)t5);
    t12 = (t0 + 3528);
    t16 = (t12 + 56U);
    t17 = *((char **)t16);
    xsi_vlog_generic_convert_bit_index(t13, t11, 2, t17, 32, 1);
    t19 = (t13 + 4);
    t6 = *((unsigned int *)t19);
    t111 = (!(t6));
    if (t111 == 1)
        goto LAB65;

LAB66:    goto LAB61;

LAB63:    xsi_vlogvar_wait_assign_value(t196, t195, 0, *((unsigned int *)t197), 1, 0LL);
    goto LAB64;

LAB65:    xsi_vlogvar_wait_assign_value(t3, t2, 0, *((unsigned int *)t13), 1, 0LL);
    goto LAB66;

}


extern void work_m_00000000000909234041_1159052017_init()
{
	static char *pe[] = {(void *)Cont_46_0,(void *)Cont_47_1,(void *)Cont_48_2,(void *)Cont_46_3,(void *)Cont_47_4,(void *)Cont_48_5,(void *)Cont_46_6,(void *)Cont_47_7,(void *)Cont_48_8,(void *)Always_63_9};
	xsi_register_didat("work_m_00000000000909234041_1159052017", "isim/tes_BVB_Simple_isim_beh.exe.sim/work/m_00000000000909234041_1159052017.didat");
	xsi_register_executes(pe);
}
